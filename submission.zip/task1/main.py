
import dbscan
import kmeans
import os
from PIL import Image
import numpy as np
import matplotlib.pyplot as plt


dirname = os.path.dirname(__file__)


def pixels_to_vectors(pixels: list, height, width):
    vector_list = []
    for x in range(width):
        for y in range(height):
            current_point = []
            current_point.append(pixels[x, y][0])
            current_point.append(pixels[x, y][1])
            current_point.append(pixels[x, y][2])

            current_vector = np.array(current_point)
            vector_list.append(current_vector)
    return vector_list


def clusters_to_image(cluster_per_point_list: list, points: list, width, height):
    assert(len(cluster_per_point_list) == len(points))

    cluster_count = max(cluster_per_point_list) + 1
    inverted_clusters = [[] for _ in range(cluster_count)]

    for i in range(len(cluster_per_point_list)):
        # inverted_cluster[каждому кластеру ]  = изначальная точка
        inverted_clusters[cluster_per_point_list[i]].append(points[i])

    mean_colors = [np.array([0, 0, 0]) for _ in range(cluster_count)]
    counter = [0 for _ in range(cluster_count)]
    for i in range(cluster_count):
        for elem in inverted_clusters[i]:
            mean_colors[i] = np.add(mean_colors[i], elem)
            counter[i] += 1

        mean_colors[i] = np.divide(mean_colors[i], np.array(
            [counter[i], counter[i], counter[i]]))

    clustered_image = Image.new('RGB', (width, height))
    pix = clustered_image.load()
    for x in range(width):
        for y in range(height):
            cl_id = cluster_per_point_list[y + x * height]
            if cl_id == -1:
                pix[x, y] = (0, 0, 0)
            else:
                curr_pixel = [int(x) for x in mean_colors[cl_id]]
                pix[x, y] = tuple(curr_pixel)

    return clustered_image


def main():

    images = os.listdir(
        os.path.dirname(__file__) + '/images/')
    for image in images:
        print(image)
    print("Pick an image from the list ")

    path = input()
    print("Choose the algorithm")
    # Load an image:
    print(os.path.join(dirname + '/images/', path))
    image = Image.open(os.path.join(dirname + '/images/', path))
    pixels = image.load()
    width, height = image.size

    # Turn image into list of vectors (1 vector / pixel):
    vector_list = pixels_to_vectors(pixels, height, width)

    print('Image file with dimensions {}x{} pixels turned into {} vectors.'.format(
        width, height, len(vector_list)))
    print("1 for dbscan and 2 for k means")

    selection = int(input())
    clusters = []

    if selection == 1:
        print("Enter an EPS value ")
        eps = int(input())
        print("Enter the min points")
        min_pts = int(input())
        selected = "dbscan"
        clusters = dbscan.dbscan(vector_list, min_pts, eps)
    else:
        print("Enter a value for k:")
        selected = "kmeans"
        k_value = int(input())
        clusters = kmeans.kmeans(vector_list, k_value)

    clustered_image = clusters_to_image(
        clusters, vector_list, width, height)

    plt.imsave('segmented_image.png', np.asarray(clustered_image))


if __name__ == '__main__':
    main()
