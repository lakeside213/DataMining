Author: _Olamilekan Korede Koku_ , _Khakharova, Taisiya_  
Brandenburg University of Technology  
Foundations of Data Mining

# Implementation of K means and DBSCAN Algorithms

Please install these dependencies with pip install:
matplotlib
numpy

1. Start the program by inputing python main.py into the terminal.
2. Pick and enter a file name from the list of images.
3. Pick the desired algorithm.
4. Follow the in-terminal instructions.
5. When clustering is complete, the segmented image can found in the root folder of the project
