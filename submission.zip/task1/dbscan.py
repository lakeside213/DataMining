import numpy as np


def ExpandCluster(D, start_object_idx, cluster_id, epsilon, minpts, cluster_per_point):
    seed = []

    for i in range(len(D)):
        if np.linalg.norm(D[start_object_idx] - D[i]) < epsilon:  # form seed
            seed.append(i)
    if len(seed) < minpts:  # start_object is not core object
        # consider start_object as noise
        cluster_per_point[start_object_idx] = 0
        return False

    # start_object is core object
    # print("start_object_idx: ", start_object_idx)

    for idx in seed:
        # assigning cluster_id to each element in seed
        cluster_per_point[idx] = cluster_id
    seed.remove(start_object_idx)  # removing start_object from seed
    cnt = 0
    # print("len(seed): ", len(seed))
    while seed:  # repeat while seed is not empty
        # print("cnt: ", cnt)
        cnt += 1
        obj_idx = np.random.choice(seed)  # chose one object from seed randomly
        neighbourhood = []
        # find neighbouhood of the object
        for i in range(len(D)):
            if np.linalg.norm(D[obj_idx] - D[i]) < epsilon:
                neighbourhood.append(i)
        if len(neighbourhood) >= minpts:  # the object is a core object
            for idx in neighbourhood:  # go through the neighbourhood
                # an element from neighbourhood is unclassified or noise
                if cluster_per_point[idx] in {0, -1}:
                    if cluster_per_point[idx] == -1:  # the element is unclassified
                        seed.append(idx)  # add to seed
                    # assigning cluster_id to the element
                    cluster_per_point[idx] = cluster_id

        seed.remove(obj_idx)  # remove object from the seed
        # print("len(seed): ", len(seed))
    return True


def dbscan(vectors: list, minpts: int, epsilon: int) -> list:
    # -1: unclassified
    # 0: noise
    # initially all points are unclassified
    cluster_per_point = [-1] * len(vectors)
    cluster_id = 1
    for i in range(len(vectors)):  # look through all points
        if cluster_per_point[i] == -1:  # if the point is not classified yet
            if ExpandCluster(vectors, i, cluster_id, epsilon, minpts, cluster_per_point):
                cluster_id += 1  # go to the next cluster
    print("k = ", max(cluster_per_point) + 1)
    return cluster_per_point
