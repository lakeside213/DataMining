from PIL import Image
import numpy as np
from matplotlib.pyplot import imshow


def kmeans(vectors: list, k=10) -> list:

    # randomly select k initial data points(these are the initial centroids)
    index_centroids_new = np.random.choice(len(vectors), size=k, replace=False)

    # store the initial data points(centroids)
    centroids_new = [vectors[i] for i in index_centroids_new]
    centroids = []
    cnt = 0  # counter

    MAX_ITERATIONS = 1e3
    while not np.array_equal(centroids, centroids_new):
        if cnt > MAX_ITERATIONS:
            break
        cnt += 1
        print("Starting iteration ", cnt)
        centroids = centroids_new

        cluster_per_point = []

        # create k classes through assignment of each point to its closest from Closest centroid from C
        for dot in vectors:
            distance_from_centroid = [np.linalg.norm(
                dot - centroid) for centroid in centroids]  # calculate distance between point and centroids
            cluster_per_point.append(
                np.argmin(distance_from_centroid))  # add minimum distance to list

        # Calculate the set of centroids for the new defined classes
        inverted_clusters = [[] for _ in range(k)]
        for i in range(len(cluster_per_point)):
            inverted_clusters[cluster_per_point[i]].append(vectors[i])
        # calculate the mean of each centroid
        centroids_new = [np.mean(arr) for arr in inverted_clusters]
    print("Clustering complete")
    print("kmeans iterations = ", cnt, ", k = ", k)
    return cluster_per_point
